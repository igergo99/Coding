
import './App.css';
import CalcComponent from './components/CalcComponent';

function App() {
  return (
    <div className="App">
      <CalcComponent/>
    </div>
  );
}

export default App;
